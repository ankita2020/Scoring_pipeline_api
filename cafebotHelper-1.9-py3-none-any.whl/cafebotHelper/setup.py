from setuptools import setup, find_packages

setup(
    name = "cafebotHelper",
    version="1.5",
    packages=["cafebotHelper"]
)