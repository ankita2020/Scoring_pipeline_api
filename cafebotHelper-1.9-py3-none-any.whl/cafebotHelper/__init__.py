#Import libraries
import numpy as np
import pandas as pd
import json
import psycopg2
import time
from clickhouse_driver import Client
import requests
from requests.auth import HTTPDigestAuth
import json
import pysftp

publish_nifi_path='/opt/cafebot/nifi/in'
publish_path='/opt/cafebot/nifi/in'
publish_path2='/opt/cafebot/nifi/in'
projectid=0

con = psycopg2.connect(dbname="cafebot", user="postgres", host="localhost", port = "6435", password="postgres")

class Chelper:
    def __init__(self):
        print("Cafebot Environment Initiated...")
        
    def publish(self, df, tablename):
        try:
            file_name = str(round(time.time() * 1000))
            file_name ='PT' + file_name +'S'
            publish_nifi_path_gen= publish_nifi_path + '/' + file_name + '.csv'
            df.to_csv(publish_nifi_path_gen,index=False)
            ver = self.isexist(tablename)

            if ver == 0:
                usr_t_name  = tablename
                self.insert(file_name,projectid, usr_t_name, ver) 
            else:
                usr_t_name  = tablename + '_V' + str(ver)

                self.insert(file_name,projectid, usr_t_name, ver)
            print('Dataframe has successfully been published to Cafebot !')
            #status(fileid,3,'Data Published')           #22/02/2021

        except Exception as e:
            print('Please check structure of the data that you are publishing !')
            #global err_status        #22/02/2021
            #err_status =1            #22/02/2021
            #status(fileid,-3,'Data Published Failed')

    def data(self, key):    
        try:
            url = "http://demo.cafebot.ai/cafe-bot/api/getQueryJob?id="+key+"&type=apikey"
            myResponse = requests.get(url, verify=True)
            #auth=HTTPDigestAuth(raw_input("username: "), raw_input("Password: ")),
            #print (myResponse.status_code)

            if(myResponse.ok):
                sql = myResponse.content
            else:
                myResponse.raise_for_status()
    
            sql_s = sql.decode("utf-8")
            sql_ls = sql_s.split('_vvvv_')
            fileid = sql_ls[0]
            sql_ls.pop(0)
            sql_fin = ''.join(sql_ls)
        
            client = Client('localhost',port=9000,user='default',database='cafebot',compression=True)
            result, columns = client.execute(sql_fin, with_column_types=True)
            df = pd.DataFrame(result, columns=[tuple[0] for tuple in columns])

            #self.status(fileid,1,'Data loading Completed')
            print('Data Loaded Successfully !')
            return(df)
        except Exception as e:
            print('Please enter the correct key or check your data again !')
            #self.status(fileid,-1,'Data loading Failed')

    def insert(self, file_name, projectid,usr_t_name, ver):
        cur = con.cursor()
        cur.execute("INSERT INTO filename (fileid,projectid, fname, version) VALUES('%s',%d,'%s',%d)"%(file_name,int(projectid),usr_t_name,int(ver)))
        con.commit()
        cur.close()


    def status(self, fileid, st,e):
        e1=str(e).replace("'","''")
        cur = con.cursor()
        cur.execute("UPDATE queue SET status = "+str(st)+",err = '"+e1+"' where fileflowid=%s" %fileid);
        con.commit()
        cur.close()
        return 1


    def increment(self, version):
        version+=1
        return version


    def isexist(self, userdefinedTablename):
        cur = con.cursor()
        cur.execute("SELECT version from filename where upper(fname) like upper('" +userdefinedTablename+ "_V%') or upper(fname) like upper('" +userdefinedTablename+ "')" + " order by version desc limit 1");
        version = cur.fetchone()
        con.commit()
        cur.close()
        if version == None:
            ver = 0
        else:
            for i in version:
                ver = self.increment(i)
                #print(ver)

        return ver
        
    def hive_sync(self, ip, user, pwd, hive_path, query):
        #hive_sync('164.52.209.60', 'hadoop',  'hdoop', '/usr/local/hadoop/hive/bin/hive', 'select * from cafebot.weather')
        try:
            cnopts = pysftp.CnOpts()
            cnopts.hostkeys = None

            sftp = pysftp.Connection(ip, username=user, password=pwd, cnopts=cnopts)

            cmd = ''+hive_path+' -e "'+query+';"'
            #cmd = 'ls -l'
            result = sftp.execute(cmd)

            n_l =[]
            for l in result:
                l = str(l).replace('\\n','').replace('b','')
                n_l.append(str(l).replace("'","").split('\\t'))

            df = pd.DataFrame(data = n_l[1:], columns = n_l[0])

            return df
        except Exception as e:
            print('Please enter the correct server information, hive path or hive query !')
            