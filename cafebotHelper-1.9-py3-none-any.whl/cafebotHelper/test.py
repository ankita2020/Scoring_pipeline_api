from scipy import stats
import pandas as pd
import json
import sa

help_obj = sa.Chelper()
k = '9e7e607c-38fc-4fc2-a5b7-0188502d24bb'
#Enter the column which has integer data type.Column should be >=0
col='p400_policy'
def main():
    #df = 'http://164.52.206.3:3030/cafe-bot/api/getJsonData?id=9615de11-d7b1-4449-b346-15bfffb834b1&fullds=0&offset=0&limit=100'
    df = help_obj.data(k)
    if col in df:
        df[col] =df[col].astype('int64')
        transform = df[col].values
        # transform values and store as "dft"
        dft = stats.boxcox(transform)
        df['box_cox'] = dft[0]
    
    else:
        return None
    
    return help_obj.publish(df,'boxcox')

main()